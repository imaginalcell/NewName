Open Pong.exe
	Player One (left)
		q - moves up
		a - moves down
	player Two (right)
		p - moves up
		; - moves down